package com.example.techassist

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnStart: Button
    private lateinit var btnExit: Button

    private val overlayPermLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                requestWriteSettingsOrStart()
            } else {
                toast("未授予悬浮窗权限，无法启动辅助")
            }
        }

    private val writeSettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.System.canWrite(this)) {
                startAssistService()
            } else {
                toast("未授予修改系统设置权限，亮度调节将不可用")
                startAssistService()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart = findViewById(R.id.btnStart)
        btnExit = findViewById(R.id.btnExit)

        btnStart.applyPressEffect()
        btnExit.applyPressEffect()

        btnStart.setOnClickListener { onStartClicked() }
        btnExit.setOnClickListener {
            stopService(Intent(this, AssistService::class.java))
            finishAffinity()
        }
    }

    private fun onStartClicked() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermLauncher.launch(intent)
        } else {
            requestWriteSettingsOrStart()
        }
    }

    private fun requestWriteSettingsOrStart() {
        if (Settings.System.canWrite(this)) {
            startAssistService()
        } else {
            try {
                writeSettingsLauncher.launch(
                    Intent(
                        Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startAssistService()
            }
        }
    }

    private fun startAssistService() {
        startService(Intent(this, AssistService::class.java))
        toast("辅助已启动")
        moveTaskToBack(true)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun View.applyPressEffect() {
        setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }
}