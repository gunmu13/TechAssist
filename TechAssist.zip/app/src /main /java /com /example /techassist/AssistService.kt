package com.example.techassist

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.roundToInt

class AssistService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var audioManager: AudioManager
    private lateinit var panel: View
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var tvBrightness: TextView
    private lateinit var tvVolume: TextView
    private lateinit var sbBrightness: SeekBar
    private lateinit var sbVolume: SeekBar

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        buildPanel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun buildPanel() {
        panel = LayoutInflater.from(this).inflate(R.layout.window_assist, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        windowManager.addView(panel, params)

        tvBrightness = panel.findViewById(R.id.tvBrightnessValue)
        tvVolume = panel.findViewById(R.id.tvVolumeValue)
        sbBrightness = panel.findViewById(R.id.sbBrightness)
        sbVolume = panel.findViewById(R.id.sbVolume)

        setupDrag(panel.findViewById(R.id.dragHandle))
        setupBrightness()
        setupVolume()

        panel.findViewById<View>(R.id.btnClose).setOnClickListener { stopSelf() }
    }

    private fun setupDrag(handle: View) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(panel, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupBrightness() {
        val current = currentBrightnessPercent()
        sbBrightness.max = 100
        sbBrightness.progress = current
        tvBrightness.text = "$current%"

        sbBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvBrightness.text = "$progress%"
                if (fromUser) applyBrightness(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun applyBrightness(percent: Int) {
        val value = (percent.coerceIn(1, 100) * 255f / 100f).roundToInt().coerceIn(1, 255)
        try {
            Settings.System.putInt(
                contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(
                contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                value
            )
        } catch (e: Exception) {
        }
    }

    private fun currentBrightnessPercent(): Int {
        val v = Settings.System.getInt(
            contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128
        )
        return (v * 100f / 255f).roundToInt().coerceIn(1, 100)
    }

    private fun setupVolume() {
        val current = currentVolumePercent()
        sbVolume.max = 100
        sbVolume.progress = current
        tvVolume.text = "$current%"

        sbVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvVolume.text = "$progress%"
                if (fromUser) applyVolume(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun applyVolume(percent: Int) {
        try {
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val index = (percent.coerceIn(0, 100) / 100f * max).roundToInt().coerceIn(0, max)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, index, 0)
        } catch (e: Exception) {
        }
    }

    private fun currentVolumePercent(): Int {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max <= 0) return 50
        val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        return (cur * 100f / max).roundToInt().coerceIn(0, 100)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (::panel.isInitialized) windowManager.removeView(panel)
        } catch (_: Exception) {
        }
    }
}